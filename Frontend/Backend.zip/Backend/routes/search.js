import express from "express";
import Document from "../models/Document.js";
import Faq from "../models/Faq.js";

const router = express.Router();

router.get("/", async (req, res) => {
  const { q, type } = req.query;

  let results = [];

  if (type === "All" || type === "Documents") {
    const docs = await Document.find({
      title: { $regex: q, $options: "i" },
    });

    results.push(
      ...docs.map((d) => ({
        id: d._id,
        type: "Document",
        title: d.title,
        source: d.collection,
        snippet: d.title,
        match: 80,
      }))
    );
  }

  if (type === "All" || type === "FAQs") {
    const faqs = await Faq.find({
      q: { $regex: q, $options: "i" },
    });

    results.push(
      ...faqs.map((f) => ({
        id: f._id,
        type: "FAQ",
        title: f.q,
        source: f.cat,
        snippet: f.a,
        match: 90,
      }))
    );
  }

  res.json({ data: results, total: results.length });
});

export default router;