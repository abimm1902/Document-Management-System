import express from "express";
import Faq from "../models/Faq.js";

const router = express.Router();

// ➕ Add FAQ
router.post("/", async (req, res) => {
  const faq = new Faq(req.body);
  await faq.save();
  res.json(faq);
});

// 📄 Get FAQs
router.get("/", async (req, res) => {
  const { search, category } = req.query;

  const query = {};
  if (category) query.cat = category;
  if (search) query.q = { $regex: search, $options: "i" };

  const data = await Faq.find(query);
  res.json({ data });
});

// ✏️ Update
router.put("/:id", async (req, res) => {
  const faq = await Faq.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });
  res.json(faq);
});

// ❌ Delete
router.delete("/:id", async (req, res) => {
  await Faq.findByIdAndDelete(req.params.id);
  res.json({ success: true });
});

// 📊 Count
router.get("/count", async (req, res) => {
  const count = await Faq.countDocuments();
  res.json({ count });
});

export default router;