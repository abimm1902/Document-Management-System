import express from "express";
import Document from "../models/Document.js";
import multer from "multer";
import path from "path";

const router = express.Router();


// ✅ Multer setup
const storage = multer.diskStorage({
  destination: "./uploads",
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage });


// 📥 Upload Document
router.post("/upload", upload.single("file"), async (req, res) => {
  try {
    const doc = new Document({
      ...req.body,
      fileUrl: `/uploads/${req.file.filename}`,
      originalName: req.file.originalname,
      type: req.file.mimetype.includes("pdf")
        ? "PDF"
        : req.file.mimetype.includes("word")
        ? "DOCX"
        : "XLSX",
    });

    await doc.save();

    res.json({
      ...doc._doc,
      id: doc._id, // ✅ important
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


// 📄 Get Documents (FIXED)
router.get("/", async (req, res) => {
  try {
    const { page = 1, per_page = 10, search, status, collection, type } = req.query;

    const query = {};
    if (status) query.status = status;
    if (collection) query.collection = collection;
    if (type) query.type = type;
    if (search) query.title = { $regex: search, $options: "i" };

    const data = await Document.find(query)
      .skip((page - 1) * per_page)
      .limit(Number(per_page))
      .sort({ updatedAt: -1 });

    const total = await Document.countDocuments(query);

    // ✅ convert _id → id
    const formatted = data.map(d => ({
      ...d._doc,
      id: d._id,
    }));

    res.json({ data: formatted, total });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


// ✏️ UPDATE DOCUMENT (FIXED)
router.put("/:id", async (req, res) => {
  try {
    const updatedDoc = await Document.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (!updatedDoc) {
      return res.status(404).json({ error: "Document not found" });
    }

    res.json({
      ...updatedDoc._doc,
      id: updatedDoc._id, // ✅ important
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


// ❌ DELETE DOCUMENT (FIXED)
router.delete("/:id", async (req, res) => {
  try {
    const deletedDoc = await Document.findByIdAndDelete(req.params.id);

    if (!deletedDoc) {
      return res.status(404).json({ error: "Document not found" });
    }

    res.json({ success: true, message: "Deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


// 📊 Stats
router.get("/stats", async (req, res) => {
  const total = await Document.countDocuments();
  res.json({ total });
});

export default router;