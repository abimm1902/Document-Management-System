import express from "express";
import cors from "cors";
import connectDB from "./db.js";

import documentRoutes from "./routes/documents.js";
import faqRoutes from "./routes/faqs.js";
import searchRoutes from "./routes/search.js";

const app = express();

connectDB();

app.use(cors());
app.use(express.json());
app.use("/uploads", express.static("uploads"));

// Routes
app.use("/api/documents", documentRoutes);
app.use("/api/faqs", faqRoutes);
app.use("/api/search", searchRoutes);

app.get("/", (req, res) => {
  res.send("🚀 API Running");
});

app.listen(5000, () => console.log("Server running on port 5000"));