import mongoose from "mongoose";

const documentSchema = new mongoose.Schema(
  {
    title: String,
    collection: String,
    author: String,
    status: {
      type: String,
      enum: ["draft", "review", "published"],
      default: "draft",
    },
    pages: Number,
    type: String,
    fileUrl: String,
    originalName: String,
    views: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export default mongoose.model("Document", documentSchema);