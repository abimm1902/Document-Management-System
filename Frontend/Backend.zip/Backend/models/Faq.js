import mongoose from "mongoose";

const faqSchema = new mongoose.Schema(
  {
    q: String,
    a: String,
    cat: String,
  },
  { timestamps: true }
);

export default mongoose.model("Faq", faqSchema);